"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HouseSystem = void 0;
var HouseSystem;
(function (HouseSystem) {
    HouseSystem["PLACIDUS"] = "PLACIDUS";
    HouseSystem["KOCH"] = "KOCH";
    HouseSystem["CAMPANUS"] = "CAMPANUS";
    HouseSystem["REGIOMONTANUS"] = "REGIOMONTANUS";
    HouseSystem["WHOLE_SIGN"] = "WHOLE_SIGN";
    HouseSystem["EQUAL"] = "EQUAL";
})(HouseSystem || (exports.HouseSystem = HouseSystem = {}));
